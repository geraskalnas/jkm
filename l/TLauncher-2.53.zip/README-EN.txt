
.......................................Linux.......................................
- If you do not want to run out of protection (unspecified developer) (Ubuntu):
1) Right-click on the file, go to "Properties."
2) Go to the "Permissions" tab and check the box next to "Enable file execution as a program".

- If the launcher did not start or an error occurred:
1) Install Java: sudo apt-get install openjdk-8-jre
2) After install JavaFX: sudo apt-get install openjfx
(If you have Java 9 or 10, you need to install Java 8 and get the launcher to work from it,
or completely remove Java 9 or 10.)

- Important! We recommend that you run with root if you run without root privileges,
then there are problems with the graphics (gpu).
Run as follows:
1) Navigate to the client folder using the CD command
2) Running: sudo java -jar TLauncher-2.53.jar

.......................................MacOS.......................................
- If you do not want to run out of protection (unspecified developer)
1) Open "Settings" and go to "Security"
2) Click on "Confirm open". The launcher will open!

- If the launcher did not start or an error occurred:
1) Install Java again by downloading the installer from the official site https://java.com/